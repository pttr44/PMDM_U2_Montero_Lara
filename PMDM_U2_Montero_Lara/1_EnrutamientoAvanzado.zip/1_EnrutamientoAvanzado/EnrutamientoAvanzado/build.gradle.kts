// Top-level build file
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.navigation.safeargs) apply false // SafeArgs (variante Java)
}
